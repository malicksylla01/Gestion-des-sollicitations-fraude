export class Constants {
    static error500message: string = 'Une erreur interne s\'est produite'
    static error422message: string = 'Une erreur interne s\'est produite'
    static apiKeys: object = ['Tdiwibr17', 'P@ssword2', '3wEK3fldPkQ.5HWkXjvZ8edvLKF7']
    static category(): object {
        return [
            {
            "key": "appels_a_candidature",
            "text": "Appels à candidature"
            },
        ]
    }
}
