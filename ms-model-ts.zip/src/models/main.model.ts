import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    slug: {
        type: String,
        unique: true,
    },
    token:  String, //
    status: {
        type: String,
        default:  'active' // active / archived / delayed
    },
},
{timestamps: true});

/*
|--------------------------------------------
| ADDITIONAL SCHEMAS APPEAR HERE
|--------------------------------------------
*/
export const MainModel = mongoose.model('mainCollection', userSchema);
